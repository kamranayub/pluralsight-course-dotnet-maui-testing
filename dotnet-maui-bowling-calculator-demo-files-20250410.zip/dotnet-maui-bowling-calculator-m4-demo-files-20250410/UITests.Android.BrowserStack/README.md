﻿# BrowserStack (Android)

Using multiple references from the [official BrowserStack xUnit sample][1] to the [.NET MAUI sample][2], I was able to get the BrowserStack test project working **on Windows and Visual Studio 2022.** I was _not_ able to get it working on my M1 Mac.

## Executing the Tests

1. You will need your own BrowserStack account and environment variables set up.
1. Build the App in Release mode and deploy it to an emulator so it gets packaged up into a signed `.apk` file.
1. You can run the tests in Visual Studio test explorer like normal.

You may need to [unblock](https://stackoverflow.com/a/77863931/109458) the `.config/dotnet-tools.json` file if you get a warning about it being blocked in the `adapter.log` or `usage.log` file.

## .NET Compatibilities

- Current `BrowserStack.TestAdapter` and `browserstack-sdk` tools are only compatible with .NET 8
  - _Workaround:_ Create a separate BrowserStack project targeting `net8.0`
  - _Workaround:_ Define a `BROWSERSTACK` constant for pragma directives
- Not compatible with xUnit 3
  - _Workaround:_ Use xUnit 2
  - _Workaround:_ Use `IClassFixture<AppiumFixture>` for BrowserStack mode
  

## Windows Troubleshooting

Initially I had problems with using the xUnit runner, and perhaps .NET 9 being installed. I tried using `global.json` and the log file indicates it successfully is using .NET 8 for the BrowserStack adapter.

The error I was getting is:

```
2025-03-20 00:12:28.8505|INFO|BStack.VisualStudio.TestAdapter.BStackAdapter|xunit test started from test explorer
2025-03-20 00:12:28.8655|INFO|A.b|Invoking browserstack-sdk with args: --skip-build-browserstack "E:\Development\Contrib\dotnet-maui-bowling-calculator\UITests.Android.BrowserStack\bin\Debug\net8.0\UITests.Android.BrowserStack.dll"" --settings "C:\Users\subka\AppData\Local\Temp\.browserstack\.runsettings" --filter "(FullyQualifiedName=UITests.GameTests.AppCanPlayTwoPlayerGameToTheEnd&DisplayName=UITests.GameTests.AppCanPlayTwoPlayerGameToTheEnd)"
2025-03-20 00:12:28.8655|INFO|A.b|Setting test assembly Path - E:\Development\Contrib\dotnet-maui-bowling-calculator\UITests.Android.BrowserStack\bin\Debug\net8.0\UITests.Android.BrowserStack.dll
2025-03-20 00:12:28.8655|ERROR|A.b|browserstack-sdk failed: System.ComponentModel.Win32Exception (2): An error occurred trying to start process 'dotnet' with working directory 'E:\Development\Contrib\dotnet-maui-bowling-calculator\UITests.Android.BrowserStack\'. The system cannot find the file specified.
   at System.Diagnostics.Process.StartWithCreateProcess(ProcessStartInfo startInfo)
   at A.b.A(String, String, Dictionary`2 envVariables)
   at A.b.A(String, String, String filterExpression)
   at A.b.A(IEnumerable`1 tests, IRunContext, IFrameworkHandle, String)
2025-03-20 00:12:28.8655|INFO|A.b|Cleaning up adapter
2025-03-20 00:12:28.8770|INFO|A.b|Getting results from: C:\Users\subka\AppData\Local\Temp\.browserstack
2025-03-20 00:12:28.8770|ERROR|A.b|Couldn't get results from: C:\Users\subka\AppData\Local\Temp\.browserstack : System.IO.DirectoryNotFoundException: Could not find a part of the path 'C:\Users\subka\AppData\Local\Temp\.browserstack\results_dotnet\result_0\NUnit-Browserstack.xml'.
   at Microsoft.Win32.SafeHandles.SafeFileHandle.CreateFile(String fullPath, FileMode mode, FileAccess access, FileShare share, FileOptions options)
   at Microsoft.Win32.SafeHandles.SafeFileHandle.Open(String fullPath, FileMode mode, FileAccess access, FileShare share, FileOptions options, Int64 preallocationSize, Nullable`1 unixCreateMode)
   at System.IO.Strategies.OSFileStreamStrategy..ctor(String path, FileMode mode, FileAccess access, FileShare share, FileOptions options, Int64 preallocationSize, Nullable`1 unixCreateMode)
   at System.IO.Strategies.FileStreamHelpers.ChooseStrategyCore(String path, FileMode mode, FileAccess access, FileShare share, FileOptions options, Int64 preallocationSize, Nullable`1 unixCreateMode)
   at System.IO.FileStream..ctor(String path, FileMode mode, FileAccess access, FileShare share, Int32 bufferSize)
   at System.Xml.XmlDownloadManager.GetStream(Uri uri, ICredentials credentials, IWebProxy proxy)
   at System.Xml.XmlTextReaderImpl.OpenUrl()
   at System.Xml.XmlTextReaderImpl.Read()
   at System.Xml.XmlLoader.Load(XmlDocument doc, XmlReader reader, Boolean preserveWhitespace)
   at System.Xml.XmlDocument.Load(XmlReader reader)
   at System.Xml.XmlDocument.Load(String filename)
   at A.b.b(String )
```

Besides the `NUnit-BrowserStack.xml` file error, it just seemed to die when executing the `dotnet` command.

### How I Fixed It

I worked backwards from the BrowserStack XUnit sample and reset my project file and moved all the test code into the project (no `UITests.Shared`).

After doing that, **it worked.** I suspect it could have been due to several issues:

- Including a `.runsettings` file
- Using a newer Microsoft Test SDK version
- Using `0.*` as the dependency version for `BrowserStack.TestAdapter`
- Switching to an empty `new AppiumOptions()` for the Android `AppiumSetup` fixture.

What would cause the adapter to fail, I am not sure. [I reported this as an issue](https://github.com/browserstack/xunit-appium-app-browserstack/issues/3).

## macOS Troubleshooting

I have a MacBook Pro M1 Max and for macOS Apple-silicon the BrowserStack docs say you need the dotnet x64 SDK installed ([8.0](https://dotnet.microsoft.com/en-us/download/dotnet/8.0))
  - But: the `dotnet browserstack-sdk setup-dotnet` did not work for me
  - So I used the MacOS x64 installer (installs to `/usr/local/share/dotnet/x64`)
  - My alias is `alias dotnet64="/usr/local/share/dotnet/x64/dotnet"` in my `~/.zshrc` file

Supposedly you can run:

```
dotnet build
dotnet64 test
```

I was not able to get it working on macOS and once I configured `dotnet64` alias to point to my x64 install, I got this when running tests:

```
System.AggregateException : One or more errors occurred. (The type initializer for '<Module>' threw an exception.) (The following constructor parameters did not have matching fixture data: AppiumFixture appium)
---- System.TypeInitializationException : The type initializer for '<Module>' threw an exception.
-------- HarmonyLib.HarmonyException : Patching exception in method System.Void OpenQA.Selenium.Remote.HttpCommandExecutor::.ctor(System.Uri addressOfRemoteServer, System.TimeSpan timeout, System.Boolean enableKeepAlive)
------------ System.DllNotFoundException : Unable to load shared library '/tmp/mm-exhelper.dylib.5nseTm' or one of its dependencies. In order to help diagnose loading problems, consider setting the DYLD_PRINT_LIBRARIES environment variable: 
dlopen(/usr/local/share/dotnet/x64/shared/Microsoft.NETCore.App/8.0.14//tmp/mm-exhelper.dylib.5nseTm, 0x0001): tried: '/usr/local/share/dotnet/x64/shared/Microsoft.NETCore.App/8.0.14//tmp/mm-exhelper.dylib.5nseTm' (no such file), '/System/Volumes/Preboot/Cryptexes/OS/usr/local/share/dotnet/x64/shared/Microsoft.NETCore.App/8.0.14//tmp/mm-exhelper.dylib.5nseTm' (no such file), '/usr/local/share/dotnet/x64/shared/Microsoft.NETCore.App/8.0.14//tmp/mm-exhelper.dylib.5nseTm' (no such file)
dlopen(/tmp/mm-exhelper.dylib.5nseTm, 0x0001): Library not loaded: libSystem.dylib
  Referenced from: <4C4C44E3-5555-3144-A11C-E7BEC362C769> /private/tmp/mm-exhelper.dylib.5nseTm
  Reason: tried: 'libSystem.dylib' (no such file), '/System/Volumes/Preboot/Cryptexes/OSlibSystem.dylib' (no such file), 'libSystem.dylib' (no such file), '/opt/homebrew/lib/libSystem.dylib' (no such file), '/opt/homebrew/lib/libSystem.dylib' (no such file), '/libSystem.dylib' (no such file), '/Users/kamranicus/dev/contrib/dotnet-maui-bowling-calculator/UITests.Android.BrowserStack/bin/Debug/net8.0/libSystem.dylib' (no such file), '/System/Volumes/Preboot/Cryptexes/OS/Users/kamranicus/dev/contrib/dotnet-maui-bowling-calculator/UITests.Android.BrowserStack/bin/Debug/net8.0/libSystem.dylib' (no such file), '/Users/kamranicus/dev/contrib/dotnet-maui-bowling-calculator/UITests.Android.BrowserStack/bin/Debug/net8.0/libSystem.dylib' (no such file), '/opt/homebrew/lib/libSystem.dylib' (no such file), '/opt/homebrew/lib/libSystem.dylib' (no such file), '/libSystem.dylib' (no such file)
```

I don't know much about OSX Darwin vs. macOS Apple silicon but this feels like an incompatibility?

```
❯ otool -L /tmp/mm-exhelper.dylib.5nseTm
/tmp/mm-exhelper.dylib.5nseTm:
        exhelper_macos_x86_64.dylib (compatibility version 0.0.0, current version 0.0.0)
        libSystem.dylib (compatibility version 0.0.0, current version 0.0.0)
```

**arm64 vs. x64**

It was my understanding that for Apple silicon you'd want dotnet _arm64_ installed, but the BrowserStack guide says to set up x64 as well (for Intel? Why?).

Switching to .net 8.0 with arm64 produced the following error:

```
System.TypeInitializationException : The type initializer for '<Module>' threw an exception.
---- HarmonyLib.HarmonyException : Patching exception in method System.Void OpenQA.Selenium.Remote.HttpCommandExecutor::.ctor(System.Uri addressOfRemoteServer, System.TimeSpan timeout, System.Boolean enableKeepAlive)
-------- System.NotImplementedException : The method or operation is not implemented.
  Stack Trace:
     at System.RuntimeTypeHandle.GetActivationInfo(RuntimeType rt, & pfnAllocator, Void*& vAllocatorFirstArg, & pfnCtor, Boolean& ctorIsPublic)
   at System.RuntimeType.ActivatorCache..ctor(RuntimeType rt)
   at System.RuntimeType.CreateInstanceDefaultCtor(Boolean publicOnly, Boolean wrapExceptions)
   at System.RuntimeType.CreateInstanceImpl(BindingFlags bindingAttr, Binder binder, Object[] args, CultureInfo culture)
   at ReflectionAbstractionExtensions.<>c__DisplayClass0_0.<CreateTestClass>b__0() in C:\Dev\xunit\xunit\src\xunit.execution\Extensions\ReflectionAbstractionExtensions.cs:line 42
   at ReflectionAbstractionExtensions.CreateTestClass(ITest test, Type testClassType, Object[] constructorArguments, IMessageBus messageBus, ExecutionTimer timer, CancellationTokenSource cancellationTokenSource) in C:\Dev\xunit\xunit\src\xunit.execution\Extensions\ReflectionAbstractionExtensions.cs:line 42
----- Inner Stack Trace -----
   at HarmonyLib.PatchClassProcessor.ReportException(Exception exception, MethodBase original)
   at HarmonyLib.PatchClassProcessor.Patch()
   at HarmonyLib.Harmony.<>c.<PatchAllUncategorized>b__12_1(PatchClassProcessor patchClass)
   at HarmonyLib.CollectionExtensions.Do[T](IEnumerable`1 sequence, Action`1 action)
   at HarmonyLib.CollectionExtensions.DoIf[T](IEnumerable`1 sequence, Func`2 condition, Action`1 action)
   at HarmonyLib.Harmony.PatchAllUncategorized(Assembly assembly)
   at BrowserstackPatcher.DoPatching() in /Users/kamranicus/dev/contrib/dotnet-maui-bowling-calculator/UITests.Android.BrowserStack/obj/Debug/net8.0/BrowserStackPatch.cs:line 132
   at Initializer.Run() in /Users/kamranicus/dev/contrib/dotnet-maui-bowling-calculator/UITests.Android.BrowserStack/obj/Debug/net8.0/BrowserStackPatch.cs:line 110
   at .cctor()
----- Inner Stack Trace -----
   at HarmonyLib.PatchFunctions.UpdateWrapper(MethodBase original, PatchInfo patchInfo)
   at HarmonyLib.PatchClassProcessor.ProcessPatchJob(Job job)
```

My `dotnet --info`:

```
dotnet --info
.NET SDK:
 Version:           8.0.407
 Commit:            cac65f27eb
 Workload version:  8.0.400-manifests.011c56c6
 MSBuild version:   17.11.26+2b19be476

Runtime Environment:
 OS Name:     Mac OS X
 OS Version:  15.3
 OS Platform: Darwin
 RID:         osx-arm64
 Base Path:   /usr/local/share/dotnet/sdk/8.0.407/

.NET workloads installed:
Configured to use loose manifests when installing new manifests.
There are no installed workloads to display.

Host:
  Version:      9.0.1
  Architecture: arm64
  Commit:       c8acea2262

.NET SDKs installed:
  8.0.405 [/usr/local/share/dotnet/sdk]
  8.0.407 [/usr/local/share/dotnet/sdk]
  9.0.100 [/usr/local/share/dotnet/sdk]
  9.0.101 [/usr/local/share/dotnet/sdk]
  9.0.102 [/usr/local/share/dotnet/sdk]

.NET runtimes installed:
  Microsoft.AspNetCore.App 8.0.12 [/usr/local/share/dotnet/shared/Microsoft.AspNetCore.App]
  Microsoft.AspNetCore.App 8.0.14 [/usr/local/share/dotnet/shared/Microsoft.AspNetCore.App]
  Microsoft.AspNetCore.App 9.0.0 [/usr/local/share/dotnet/shared/Microsoft.AspNetCore.App]
  Microsoft.AspNetCore.App 9.0.1 [/usr/local/share/dotnet/shared/Microsoft.AspNetCore.App]
  Microsoft.NETCore.App 8.0.12 [/usr/local/share/dotnet/shared/Microsoft.NETCore.App]
  Microsoft.NETCore.App 8.0.14 [/usr/local/share/dotnet/shared/Microsoft.NETCore.App]
  Microsoft.NETCore.App 9.0.0 [/usr/local/share/dotnet/shared/Microsoft.NETCore.App]
  Microsoft.NETCore.App 9.0.1 [/usr/local/share/dotnet/shared/Microsoft.NETCore.App]

Other architectures found:
  x64   [/usr/local/share/dotnet/x64]
    registered at [/etc/dotnet/install_location_x64]

Environment variables:
  Not set

global.json file:
  /Users/kamranicus/dev/contrib/dotnet-maui-bowling-calculator/UITests.Android.BrowserStack/global.json
```

And `dotnet64 --info`:

```
dotnet64 --info
.NET SDK:
 Version:           8.0.407
 Commit:            cac65f27eb
 Workload version:  8.0.400-manifests.20e9918b
 MSBuild version:   17.11.26+2b19be476

Runtime Environment:
 OS Name:     Mac OS X
 OS Version:  15.3
 OS Platform: Darwin
 RID:         osx-x64
 Base Path:   /usr/local/share/dotnet/x64/sdk/8.0.407/

.NET workloads installed:
Configured to use loose manifests when installing new manifests.
There are no installed workloads to display.

Host:
  Version:      8.0.14
  Architecture: x64
  Commit:       1584e49360

.NET SDKs installed:
  8.0.407 [/usr/local/share/dotnet/x64/sdk]

.NET runtimes installed:
  Microsoft.AspNetCore.App 8.0.14 [/usr/local/share/dotnet/x64/shared/Microsoft.AspNetCore.App]
  Microsoft.NETCore.App 8.0.14 [/usr/local/share/dotnet/x64/shared/Microsoft.NETCore.App]

Other architectures found:
  arm64 [/usr/local/share/dotnet]
    registered at [/etc/dotnet/install_location_arm64]

Environment variables:
  Not set

global.json file:
  /Users/kamranicus/dev/contrib/dotnet-maui-bowling-calculator/UITests.Android.BrowserStack/global.json
```

So I have both .NET 8.0.407 arm64 and x64 installed, and neither one works.

Feeding the logs and output to ChatGPT does not offer much else, saying that it looks like this relies on Rosetta 2 for emulation, it suggested updating it:

```sh
softwareupdate --install-rosetta --agree-to-license
```

And to print out DYDL libraries:

```sh
DYLD_PRINT_LIBRARIES=1 dotnet64 test 
```

But that did not seem to help it much to understand what's going on -- it says the same thing I'm thinking, that it's some incompatibility with Harmony patching or arm64 vs. x64.

### Related

- [Cannot run test suite on M1 machine](https://stackoverflow.com/questions/77919345/cannot-run-test-suite-on-m1-machine)

## References

- [BrowserStack: C# xUnit sample][1]
- [BrowserStack: C# xUnit Integration documentation](https://www.browserstack.com/docs/app-automate/appium/getting-started/c-sharp/xunit/integrate-your-tests)
- [.NET MAUI: NUnit + BrowserStack sample][2]

[1]: https://github.com/browserstack/xunit-appium-app-browserstack
[2]: https://github.com/dotnet/maui-samples/blob/main/9.0/UITesting/BrowserStackAppiumMaui/README.md