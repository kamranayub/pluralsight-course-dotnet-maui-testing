﻿using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Appium.Service;
using OpenQA.Selenium.Appium.Windows;
using UITests;

[assembly: AssemblyFixture(typeof(AppiumFixture))]

namespace UITests;

public class AppiumFixture : IDisposable
{
    private readonly AppiumDriver? session;
    private readonly AppiumLocalService? service;

    public AppiumDriver App => session ?? throw new NullReferenceException("AppiumDriver is null");

    public string PackageId => "com.kamranayub.bowlingcalculator_rvq2daxkc9t10!App";

    public AppiumFixture()
    {
        try
        {
            // If you started an Appium server manually, make sure to comment out the next line
            // This line starts a local Appium server for you as part of the test run
            service = AppiumServerHelper.StartAppiumLocalServer();

            var windowsOptions = new AppiumOptions
            {
                // Specify windows as the driver, typically don't need to change this
                AutomationName = "windows",
                // Device name for Windows
                DeviceName = "WindowsPC",
                // Always Windows for Windows
                PlatformName = "Windows",
                // The identifier of the deployed application to test
                // See Package.appxmanifest for the Package Family Name ID
                App = PackageId,
            };

            // Note there are many more options that you can use to influence the app under test according to your needs

            session = new WindowsDriver(windowsOptions);            
        } 
        catch (Exception ex)
        {
            Dispose();

            if (ex.Message.Contains("Value does not fall within the expected range."))
            {
                throw new Exception("Make sure you have the correct Package Family Name ID from the Package.appxmanifest specified, and make sure you've already published and installed the app on the Windows machine", ex);
            }

            throw;
        }

        Assert.NotNull(session);
    }

    public void Dispose()
    {
        session?.Quit();

        // If an Appium server was started locally above, make sure we clean it up here
        AppiumServerHelper.DisposeAppiumLocalServer(service);        
    }
}