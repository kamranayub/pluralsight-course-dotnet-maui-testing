﻿using BowlingCalculator.Storage;
using CommunityToolkit.Maui;
using CommunityToolkit.Mvvm.Messaging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BowlingCalculator
{
    public static class CoreRegistration
    {
        public static void Register(IServiceCollection services)
        {
            RegisterServices(services);
            RegisterViewModels(services);
            RegisterViews(services);
        }

        private static void RegisterServices(IServiceCollection services)
        {
            services.AddSingleton<IMessenger>(WeakReferenceMessenger.Default);
            services.AddSingleton(Launcher.Default);
            services.AddSingleton(Browser.Default);
            services.AddSingleton(Email.Default);
            services.AddSingleton<LiteDatabaseService>();
            services.AddSingleton<BowlingStore>();
            services.AddSingleton<ThemeStore>();
        }

        private static void RegisterViewModels(IServiceCollection services)
        {
            services.AddSingleton<GameViewModel>();
            services.AddSingleton<AboutViewModel>();
            services.AddTransient<AddPlayerViewModel>();
            services.AddTransient<ChangelogViewModel>();
            services.AddTransientPopup<PinPickerView, PinPickerViewModel>();
        }

        private static void RegisterViews(IServiceCollection services)
        {
            services.AddSingleton<GameView>();
            services.AddSingleton<AboutView>();
            services.AddTransient<AddPlayerView>();
            services.AddTransient<ChangelogView>();
        }
    }
}
