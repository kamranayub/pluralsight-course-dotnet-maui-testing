namespace BowlingCalculator.Resources.Styles;

public partial class Styles : ResourceDictionary
{
	public Styles()
	{
		InitializeComponent();
	}
}