namespace BowlingCalculator.Resources.Styles;

public partial class Colors : ResourceDictionary
{
	public Colors()
	{
		InitializeComponent();
	}
}