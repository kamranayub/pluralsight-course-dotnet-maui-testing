﻿using CommunityToolkit.Mvvm.ComponentModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BowlingCalculator.ViewModels
{
    public class BaseViewModel : ObservableObject
    {
        private string? _title;
        public string Title
        {
            get { return _title ?? "Bowling Calculator"; }
            set
            {
                _title = value;
                OnPropertyChanged();
            }
        }

        private bool _isBusy;
        public bool IsBusy
        {
            get { return _isBusy; }
            set
            {
                _isBusy = value;
                OnPropertyChanged();
            }
        }
    }
}
