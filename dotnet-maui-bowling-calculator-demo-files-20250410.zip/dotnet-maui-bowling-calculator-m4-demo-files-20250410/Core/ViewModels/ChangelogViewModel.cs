﻿using BowlingCalculator.Models;
using BowlingCalculator.Resources;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace BowlingCalculator.ViewModels;

public class ChangelogViewModel : BaseViewModel
{

    public ObservableCollection<Release> ReleaseNotes { get; set; }

    public ChangelogViewModel()
    {
        ReleaseNotes = new ObservableCollection<Release>();

        Shell.Current.Appearing += Current_Appearing;
    }

    private void Current_Appearing(object? sender, EventArgs e)
    {
        // Get language code (en, fr, etc.)
        var languageCode = System.Globalization.CultureInfo.CurrentUICulture.TwoLetterISOLanguageName;
        var releaseDoc = XDocument.Parse(AppResources.ReleaseNotes);
        var releases = from rNode in releaseDoc.Root.Descendants()
                       let versionAttr = rNode.Attribute("version")
                       let notes = from notesNode in rNode.Descendants()
                                   let langAttr = notesNode.Attribute("lang")
                                   where langAttr != null && langAttr.Value == languageCode
                                   select notesNode
                       where notes != null &&
                             notes.Any() &&
                             versionAttr != null
                       select
                           new Release()
                           {
                               Version = versionAttr.Value,
                               Notes = notes.First().Value
                           };

        foreach(var release in releases)
        {
            ReleaseNotes.Add(release);
        }
    }
}