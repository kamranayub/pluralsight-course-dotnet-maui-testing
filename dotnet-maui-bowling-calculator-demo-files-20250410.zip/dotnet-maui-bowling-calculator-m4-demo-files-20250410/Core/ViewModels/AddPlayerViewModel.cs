﻿using BowlingCalculator.BowlingGame.Messages;
using BowlingCalculator.Storage;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using CommunityToolkit.Mvvm.Messaging;
using Microsoft.Maui.Controls;
using System.Collections.ObjectModel;
using System.Xml.Linq;

namespace BowlingCalculator.ViewModels;

public class AddPlayerViewModel : BaseViewModel
{
    private readonly IMessenger _events;
    private readonly LiteDatabaseService _db;
    private string? _player;
    private ObservableCollection<string> _recentPlayers;

    public AddPlayerViewModel(IMessenger events, LiteDatabaseService db)
    {
        _events = events;
        _db = db;
        _recentPlayers = [];
        AddPlayerCommand = new AsyncRelayCommand(AddPlayerEntry, () => CanAddPlayer);
        AddRecentPlayerCommand = new AsyncRelayCommand<string>(AddPlayer);
        ClearRecentPlayersCommand = new RelayCommand(ClearRecentPlayers, () => HasRecentPlayers);

        LoadRecentPlayers();
    }

    public IRelayCommand AddPlayerCommand { get; }

    public IRelayCommand AddRecentPlayerCommand { get; }

    public IRelayCommand ClearRecentPlayersCommand { get; }

    public ObservableCollection<string> RecentPlayers
    {
        get { return _recentPlayers; }
        set
        {
            if (Equals(value, _recentPlayers)) return;
            _recentPlayers = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(HasRecentPlayers));
        }
    }

    public bool HasRecentPlayers => RecentPlayers.Count > 0;

    public string? Player
    {
        get { return _player; }
        set
        {
            if (value == _player) return;
            _player = value;
            OnPropertyChanged();
            AddPlayerCommand.NotifyCanExecuteChanged();
        }
    }

    public bool CanAddPlayer
    {
        get
        {
            return !string.IsNullOrEmpty(Player);
        }
    }

    public async Task AddPlayerEntry()
    {
        if (string.IsNullOrWhiteSpace(Player)) return;

        await AddPlayer(Player);

        Player = null;
    }

    public async Task AddPlayer(string? name)
    {
        if (string.IsNullOrWhiteSpace(name)) return;

        _db.Current.Upsert(new RecentPlayer() { Id = name, CreatedAt = DateTime.UtcNow });

        LoadRecentPlayers();
        TrimRecentPlayers();

        await Shell.Current.GoToAsync("..");

        _events.Send(new RequestAddPlayerMessage(name), default(GameToken));
    }

    private void LoadRecentPlayers()
    {
        var recentPlayers = _db.Current.Query<RecentPlayer>()
            .OrderByDescending(x => x.CreatedAt)
            .Limit(5)
            .ToEnumerable()
            .Select(x => x.Id)
            .ToList();

        RecentPlayers = [.. recentPlayers];
    }

    private void TrimRecentPlayers()
    {
        var extraPlayers = _db.Current.Query<RecentPlayer>().Skip(5).ToList();
        extraPlayers.ForEach(p => _db.Current.Delete<RecentPlayer>(p.Id));
    }

    private void ClearRecentPlayers()
    {
        _db.Current.DeleteMany<RecentPlayer>(x => true);
        RecentPlayers = [];
    }
}