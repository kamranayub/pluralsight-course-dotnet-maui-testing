﻿using BowlingCalculator.BowlingGame.Messages;
using BowlingCalculator.Resources;
using BowlingCalculator.Storage;
using CommunityToolkit.Maui.Core;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using CommunityToolkit.Mvvm.Messaging;
using System.Collections.ObjectModel;
using System.Windows.Input;

namespace BowlingCalculator.ViewModels;

public class GameViewModel : BaseViewModel, IRecipient<Game.Reset>, IRecipient<Game.Loaded>,  IRecipient<Game.Started>, IRecipient<Game.Ended>, IRecipient<Game.InProgress>
{
    private readonly IMessenger _events;
    private readonly IPopupService _popupService;
    private BowlingPlayer? _winner;
    private Bowling _game;

    public GameViewModel(IMessenger events, BowlingStore store, IPopupService popupService)
    {
        _events = events;
        _events.RegisterAll(this, default(GameToken));

        _popupService = popupService;
        AddPlayerCommand = new AsyncRelayCommand(AddPlayer, () => CanAddPlayer);
        ResetCommand = new AsyncRelayCommand(Reset, () => CanReset);
        OpenAboutPageCommand = new AsyncRelayCommand(OpenAboutPage);
        PickPinsCommand = new AsyncRelayCommand<BowlingFrame>(PickPins);

        RunnerUps = new ObservableCollection<BowlingPlayer>();
        Game = new Bowling(events);

        var loadedGame = store.LoadFromStorage();
        if (loadedGame != null)
        {
            _events.Send(new RequestGameLoadMessage(loadedGame), default(GameToken));
        }
    }

    public IRelayCommand AddPlayerCommand { get; }
    public ICommand OpenAboutPageCommand { get; }
    public ICommand PickPinsCommand { get; }
    public IRelayCommand ResetCommand { get; }

    public Bowling Game
    {
        get { return _game; }
        set
        {
            if (Equals(value, _game)) return;
            _game = value;
            OnPropertyChanged();
            AddPlayerCommand.NotifyCanExecuteChanged();
            ResetCommand.NotifyCanExecuteChanged();
        }
    }

    public BowlingPlayer Winner
    {
        get { return _winner; }
        set
        {
            if (Equals(value, _winner)) return;
            _winner = value;
            OnPropertyChanged(nameof(Winner));
        }
    }

    public ObservableCollection<BowlingPlayer> RunnerUps { get; set; }

    public bool CanAddPlayer
    {
        get { return !Game.IsInProgress; }
    }

    public async Task AddPlayer()
    {
        await Shell.Current.GoToAsync(nameof(Views.AddPlayerView));
    }

    public bool CanReset
    {
        get { return Game.IsStarted; }
    }

    public async Task PickPins(BowlingFrame? frame)
    {
        // Do not show picker if this isn't the current frame
        if (frame?.IsCurrentFrame != true)
        {
            return;
        }

        // get available pins for the frame
        var pins = frame.GetAvailablePins();

        var result = await _popupService.ShowPopupAsync<PinPickerViewModel>(
            onPresenting: viewModel =>
        {
            viewModel.SetAvailablePins(pins);
        });

        var selectedPins = result as int?;
        if (result != null && selectedPins != null)
        {
            Game.Bowl(selectedPins.Value);
        }
    }

    public async Task OpenAboutPage()
    {
        await Shell.Current.GoToAsync(nameof(Views.AboutView));
    }

    public async Task Reset()
    {
        var confirmDialog = await Shell.Current.DisplayAlert(
            AppResources.GamePageResetDialogTitle,
            AppResources.GamePageResetDialogContent,
            accept: AppResources.GamePageResetDialogLeftButtonContent,
            cancel: AppResources.GamePageResetDialogRightButtonContent);

        if (confirmDialog)
        {
            _events.Send(new RequestGameResetMessage(), default(GameToken));
        }
        else
        {
            _events.Send(new RequestGameResetMessage(true), default(GameToken));
        }

    }

    private void HandleGameEnded() {

        // order players
        var players = Game.Players.OrderByDescending(p => p.Score);

        // winner
        Winner = players.First();

        // runner ups
        RunnerUps = [.. players.Skip(1)];
        OnPropertyChanged(nameof(RunnerUps));
    }

    #region Message Handling

    public void Receive(Game.Started message)
    {
        OnPropertyChanged(nameof(Game));

        ResetCommand.NotifyCanExecuteChanged();
        AddPlayerCommand.NotifyCanExecuteChanged();
    }

    public void Receive(Game.Ended message)
    {

        ResetCommand.NotifyCanExecuteChanged();
        HandleGameEnded();
    }

    public void Receive(Game.Reset message)
    {
        ResetCommand.NotifyCanExecuteChanged();
        AddPlayerCommand.NotifyCanExecuteChanged();
    }

    public void Receive(Game.Loaded message)
    {
        ResetCommand.NotifyCanExecuteChanged();
        AddPlayerCommand.NotifyCanExecuteChanged();

        if (Game.IsEnded) {
            HandleGameEnded();
        }
    }

    public void Receive(Game.InProgress message)
    {
        ResetCommand.NotifyCanExecuteChanged();
        AddPlayerCommand.NotifyCanExecuteChanged();
    }

    #endregion

}