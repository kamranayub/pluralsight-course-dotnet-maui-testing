﻿using BowlingCalculator.Resources;
using BowlingCalculator.Storage;
using CommunityToolkit.Mvvm.Input;

namespace BowlingCalculator.ViewModels;

public class AboutViewModel : BaseViewModel
{
    public AboutViewModel(ILauncher launcher, IBrowser browser, IEmail email, ThemeStore themeStore)
    {

        PackageName = "com.kamranayub.bowlingcalculator";
        Website = "https://github.com/kamranayub/dotnet-maui-bowling-calculator";
        PrivacyPolicy = "https://github.com/kamranayub/dotnet-maui-bowling-calculator/tree/main/PRIVACY.md";
        ProjectSite = "https://github.com/kamranayub/dotnet-maui-bowling-calculator";
        FeedbackSite = "https://github.com/kamranayub/dotnet-maui-bowling-calculator/issues";
        SupportEmail = "support@kamranayub.com";

        OpenRateCommand = new AsyncRelayCommand(OpenRate);
        OpenChangelogCommand = new AsyncRelayCommand(OpenChangelog);
        OpenWebsiteCommand = new AsyncRelayCommand(OpenWebsite);
        OpenPrivacyCommand = new AsyncRelayCommand(OpenPrivacy);
        OpenFeedbackSiteCommand = new AsyncRelayCommand(OpenFeedbackSite);
        OpenSupportEmailCommand = new AsyncRelayCommand(OpenSupportEmail);
        OpenProjectSiteCommand = new AsyncRelayCommand(OpenProjectSite);

        _launcher = launcher;
        _browser = browser;
        _email = email;
        _themeStore = themeStore;
    }

    public string Version => AppInfo.VersionString;

    private static Dictionary<AppTheme, string> _appThemeOptions = new Dictionary<AppTheme, string>()
    {
        { AppTheme.Unspecified, "System Default" },
        { AppTheme.Light, "Light" },
        { AppTheme.Dark, "Dark" }
    };
    private readonly ILauncher _launcher;
    private readonly IBrowser _browser;
    private readonly IEmail _email;
    private readonly ThemeStore _themeStore;

    public List<string> AppThemeOptions => _appThemeOptions.Values.ToList();

    private string _appThemePickerTitle;
    public string AppThemePickerTitle
    {
        get => _appThemePickerTitle;
        set
        {
            _appThemePickerTitle = value;
            OnPropertyChanged();
        }
    }

    public int SelectedAppTheme
    {
        get
        {
            var appTheme = _themeStore.GetThemePreference();
            var selected = AppThemeOptions.IndexOf(_appThemeOptions[appTheme]);
            return selected;
        }
        set
        {
            if (value < 0 || value >= _appThemeOptions.Count)
            {
                return;
            }
            var selected = _appThemeOptions.ElementAt(value).Key;

            _themeStore.SetThemePreference(selected);
            ApplyThemeChange(selected);
            OnPropertyChanged();
        }
    }

    public string PrivacyPolicy { get; set; }

    public string Website { get; set; }

    public string ProjectSite { get; set; }

    public string FeedbackSite { get; set; }

    public string SupportEmail { get; set; }

    public string PackageName { get; set; }

    public IAsyncRelayCommand OpenRateCommand { get; }

    public IAsyncRelayCommand OpenChangelogCommand { get; }

    public IAsyncRelayCommand OpenWebsiteCommand { get; }

    public IAsyncRelayCommand OpenPrivacyCommand { get; }

    public IAsyncRelayCommand OpenFeedbackSiteCommand { get; }

    public IAsyncRelayCommand OpenSupportEmailCommand { get; }

    public IAsyncRelayCommand OpenProjectSiteCommand { get; }

    public void ApplyThemeChange(AppTheme selected)
    {
        if (Application.Current == null) return;
        if (Application.Current.UserAppTheme == selected) return;

        Application.Current.UserAppTheme = selected;
    }

    public async Task OpenChangelog()
    {
        await Shell.Current.GoToAsync(nameof(Views.ChangelogView));
    }

    public async Task OpenRate()
    {
        bool supportsUri = await _launcher.CanOpenAsync("market://");

        if (supportsUri)
        {
            await _launcher.OpenAsync("market://details?id=" + PackageName);
        }
    }

    public async Task OpenWebsite()
    {
        await _browser.OpenAsync(new Uri(Website));
    }

    public async Task OpenPrivacy()
    {
        await _browser.OpenAsync(new Uri(PrivacyPolicy));
    }

    public async Task OpenFeedbackSite()
    {
        await _browser.OpenAsync(new Uri(FeedbackSite));
    }

    public async Task OpenSupportEmail()
    {
        if (_email.IsComposeSupported)
        {

            var message = new EmailMessage
            {
                Subject = "Issue with Bowling Calc app",
                BodyFormat = EmailBodyFormat.PlainText,
                To = [SupportEmail]
            };

            await _email.ComposeAsync(message);
        }
    }

    public async Task OpenProjectSite()
    {
        await _browser.OpenAsync(new Uri(ProjectSite));
    }

    internal void HandleRequestedThemeChanged(AppTheme requestedTheme)
    {
        if (requestedTheme == AppTheme.Light)
        {
            AppThemePickerTitle = AppResources.AppThemePickerTitleLight;
        }
        else if (requestedTheme == AppTheme.Dark)
        {
            AppThemePickerTitle = AppResources.AppThemePickerTitleDark;
        }
        else
        {
            AppThemePickerTitle = AppResources.AppThemePickerTitleDefault;
        }
    }
}