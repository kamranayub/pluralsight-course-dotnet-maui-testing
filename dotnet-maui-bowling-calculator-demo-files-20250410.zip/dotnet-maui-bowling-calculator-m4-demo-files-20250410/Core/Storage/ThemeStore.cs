﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BowlingCalculator.Storage
{
    public class ThemeStore
    {
        private const string ThemePreferenceKey = "BowlingCalculator:Theme";

        public AppTheme GetThemePreference()
        {
            return (AppTheme)Preferences.Default.Get(ThemePreferenceKey, (int)AppTheme.Unspecified);
        }

        public void SetThemePreference(AppTheme theme)
        {
            Preferences.Default.Set(ThemePreferenceKey, (int)theme);
        }
    }
}
