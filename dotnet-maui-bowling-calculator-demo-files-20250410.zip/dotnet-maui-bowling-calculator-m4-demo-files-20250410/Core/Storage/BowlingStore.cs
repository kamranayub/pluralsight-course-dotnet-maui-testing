﻿using BowlingCalculator.BowlingGame.Messages;
using CommunityToolkit.Mvvm.Messaging;

namespace BowlingCalculator.Storage
{
    public class BowlingStore : IRecipient<Game.Turn>, IRecipient<Game.Reset>
    {
        private readonly LiteDatabaseService _db;

        public BowlingStore(IMessenger events, LiteDatabaseService db)
        {
            events.RegisterAll(this, default(GameToken));
            _db = db;
        }

        public BowlingState? LoadFromStorage()
        {
            return _db.Current.FirstOrDefault<BowlingState>(x => x.Id == Constants.DefaultGameId);
        }

        public void Receive(Game.Turn message)
        {
            _db.Current.Upsert(message.State);
        }

        public void Receive(Game.Reset message)
        {
            if (message.Cleared)
            {
                _db.Current.Delete<BowlingState>(message.State.Id);
            }
            else
            {
                _db.Current.Upsert(message.State);
            }
        }
    }
}
