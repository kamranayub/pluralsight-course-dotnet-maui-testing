﻿using LiteDB;

namespace BowlingCalculator.Storage
{
    public class LiteDatabaseService : IDisposable
    {
        private bool disposedValue;

        public LiteDatabaseService()
        {
            Current = new LiteRepository(Path.Combine(FileSystem.AppDataDirectory, "bowling.db"));
        }

        public LiteRepository Current { get; }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    Current.Dispose();
                }

                disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }
    }
}
