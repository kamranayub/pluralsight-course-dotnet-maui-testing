﻿namespace BowlingCalculator.BowlingGame;

public class BowlingState
{
    public int Id { get; set; }
    public int CurrentFrame { get; set; }
    public int? CurrentPlayer { get; set; }
    public ICollection<PlayerState> Players { get; set; }
    public bool IsEnded { get; set; }
    public bool IsInProgress { get; set; }

    public BowlingState()
    {
        Players = new List<PlayerState>();
    }
}

public class PlayerState
{
    public PlayerState()
    {
        Frames = new List<FrameState>();
    }

    public required string Name { get; set; }

    public int Score { get; set; }

    public ICollection<FrameState> Frames { get; set; }
}

public class FrameState
{
    public int? Ball1 { get; set; }
    public int? Ball2 { get; set; }
    public int? Ball3 { get; set; }
    public int Index { get; set; }
    public int? CumulativeScore { get; set; }
    public bool IsCurrentFrame { get; set; }
}
