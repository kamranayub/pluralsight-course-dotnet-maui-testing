﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BowlingCalculator.BowlingGame.Messages;

public class Game
{

    public record Started { }

    public record InProgress { }

    public record Turn(BowlingState State);

    public record Ended(BowlingState State);

    public record Reset(BowlingState State, bool Cleared) { }

    public record Loaded { }

    public record PlayerAdded { }

}

public class RequestGameResetMessage
{
    public RequestGameResetMessage(bool clearPlayers = false)
    {
        ClearPlayers = clearPlayers;
    }

    public bool ClearPlayers { get; }
}

public class RequestAddPlayerMessage
{
    public string Player;

    public RequestAddPlayerMessage(string player)
    {
        Player = player;
    }
}

public class RequestGameLoadMessage
{
    public RequestGameLoadMessage(BowlingState state)
    {
        State = state;
    }
    public BowlingState State { get; }
}