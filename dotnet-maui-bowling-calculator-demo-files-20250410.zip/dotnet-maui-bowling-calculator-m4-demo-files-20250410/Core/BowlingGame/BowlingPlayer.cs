﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using CommunityToolkit.Mvvm.ComponentModel;

namespace BowlingCalculator.BowlingGame;

public class BowlingPlayer : ObservableObject
{
    private int _score;

    public static BowlingPlayer FromState(PlayerState player)
    {
        var newPlayer = new BowlingPlayer()
        {
            Name = player.Name,
            Score = player.Score
        };

        newPlayer.Frames.Clear();

        foreach (var frame in player.Frames)
        {
            newPlayer.Frames.Add(BowlingFrame.FromState(frame));
        }

        return newPlayer;
    }

    public BowlingPlayer()
    {
        Frames = new ObservableCollection<BowlingFrame>();
        for (var i = 0; i < Constants.Frames; i++)
        {
            var frame = new BowlingFrame() { Index = i };
            Frames.Add(frame);
        }
    }

    public string Name { get; set; }

    public int Score
    {
        get { return _score; }
        set
        {
            if (value == _score) return;
            _score = value;
            OnPropertyChanged();
        }
    }

    public ObservableCollection<BowlingFrame> Frames { get; set; }


    public void Bowl(int currentFrame, int pins)
    {
        Frames[currentFrame - 1].Bowl(pins);
    }

    public int GetScore()
    {
        return Frames.Sum(f => f.GetScore(Frames).GetValueOrDefault());
    }

    public void Reset()
    {
        Score = 0;

        foreach (var frame in Frames)
        {
            frame.Reset();
        }
    }

    internal PlayerState GetState()
    {
        return new PlayerState()
        {
            Name = Name,
            Score = Score,
            Frames = Frames.Select(f => f.GetState()).ToList()
        };
    }
}