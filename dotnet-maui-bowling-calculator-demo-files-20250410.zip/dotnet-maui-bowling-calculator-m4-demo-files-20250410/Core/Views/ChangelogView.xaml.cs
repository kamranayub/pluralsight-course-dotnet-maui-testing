namespace BowlingCalculator.Views;

public partial class ChangelogView : ContentPage
{
	public ChangelogView()
	{
		InitializeComponent();
	}
}