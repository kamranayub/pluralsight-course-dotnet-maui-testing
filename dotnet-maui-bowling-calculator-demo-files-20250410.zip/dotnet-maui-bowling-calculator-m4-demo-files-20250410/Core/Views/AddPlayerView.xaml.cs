using BowlingCalculator.ViewModels;

namespace BowlingCalculator.Views;

public partial class AddPlayerView : ContentPage
{
	public AddPlayerView(AddPlayerViewModel viewModel)
	{
		InitializeComponent();
		BindingContext = viewModel;
	}
}