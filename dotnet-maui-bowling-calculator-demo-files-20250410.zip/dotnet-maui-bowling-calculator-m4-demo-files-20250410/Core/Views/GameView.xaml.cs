namespace BowlingCalculator.Views;

public partial class GameView : ContentPage
{
    public GameView(GameViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = viewModel;
    }

}