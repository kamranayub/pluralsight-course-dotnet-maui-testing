﻿// You will have to make sure that all the namespaces match
// between the different platform specific projects and the shared
// code files. This has to do with how we initialize the AppiumDriver
// through the AppiumSetup.cs files and xUnit Collection attributes.
// Also see: https://xunit.net/docs/shared-context#collection-fixture
namespace UITests;

public class StorageTests : GameBaseTests
{
    public StorageTests(AppiumFixture appium) : base(appium)
    {
        ResetGame();
    }

    [Fact]
    public void AppCanQuitAndResumeGameInProgress()
    {
        AddPlayer("Automation Player");

        Pause();

        FindAllByAutomationId("BowlingFrameBall1").First().Click(exact: true);

        FindAllByAutomationId("PinButton").ElementAt(1).Click();

        FindAllByAutomationId("BowlingFrameBall2").First().Click(exact: true);

        FindAllByAutomationId("PinButton").ElementAt(3).Click();

        RestartApp();

        var ball1 = FindAllByAutomationId("BowlingFrameBall1").First();
        var ball2 = FindAllByAutomationId("BowlingFrameBall2").First();

        Assert.Equal("1", ball1.Text);
        Assert.Equal("3", ball2.Text);

        var playerName = FindByAutomationId("PlayerNameLabel");
        var playerScore = FindByAutomationId("PlayerScoreLabel");

        Assert.Equal("Automation Player", playerName.Text);
        Assert.Equal("4", playerScore.Text);
    }
}