﻿using OpenQA.Selenium;
using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Appium.Android;
using OpenQA.Selenium.Appium.Mac;
using OpenQA.Selenium.Appium.Windows;
using OpenQA.Selenium.Support.UI;
using System.Collections.Generic;

namespace UITests;

[Collection("Shared")]
#if BROWSERSTACK
public class BaseTest : IClassFixture<AppiumFixture>
#else
public class BaseTest
#endif
{
    private readonly AppiumFixture fixture;

    private const string MacDriverCommandTerminate = "macos: terminateApp";
    private const string MacDriverCommandLaunch = "macos: launchApp";
    private static TimeSpan ImplicitWait = TimeSpan.FromSeconds(0.75);

    public BaseTest(AppiumFixture appium)
    {
        App = appium.App;
        fixture = appium;

        App.Manage().Timeouts().ImplicitWait = ImplicitWait;
    }

    public AppiumDriver App { get; }

    /// <summary>
    /// Pauses for the specified timeout
    /// </summary>
    /// <param name="timeout"></param>
    protected void PauseFor(TimeSpan timeout)
    {
        try
        {
            var wait = new WebDriverWait(App, timeout);
            wait.Until(driver => false);
        }
        catch (WebDriverTimeoutException)
        {
            // Ignore
        }
    }

    /// <summary>
    /// Pauses for the default implicit wait time
    /// </summary>
    protected void Pause()
    {
        try
        {
            var wait = new WebDriverWait(App, ImplicitWait);
            wait.Until(driver => false);
        }
        catch (WebDriverTimeoutException)
        {
            // Ignore
        }
    }

    /// <summary>
    /// Waits for the action to complete without throwing an exception. Defaults to the implicit wait time.
    /// </summary>
    /// <param name="action"></param>
    protected void WaitFor(Action action)
    {
        try
        {
            var wait = new WebDriverWait(App, ImplicitWait);
            wait.Until(driver =>
            {
                try { action(); return true; } catch { return false; }
            });
        }
        catch (WebDriverTimeoutException)
        {
            // Ignore
        }
    }

    /// <summary>
    /// Waits for the action to complete without throwing an exception for the specified timeout.
    /// </summary>
    /// <param name="action"></param>
    /// <param name="timeout"></param>
    protected void WaitFor(Action action, TimeSpan timeout)
    {
        try
        {
            var wait = new WebDriverWait(App, timeout);
            wait.Until(driver =>
            {
                try { action(); return true; } catch { return false; }
            });
        }
        catch (WebDriverTimeoutException)
        {
            // Ignore
        }
    }

    protected AppiumElement FindByAutomationId(string id)
    {
        try
        {
            return App.FindElement(MobileBy.AccessibilityId(id));
        }
        catch (NoSuchElementException)
        {
            return App.FindElement(MobileBy.Id(id));
        }
    }

    protected IReadOnlyCollection<AppiumElement> FindAllByAutomationId(string id)
    {
        var elements = App.FindElements(MobileBy.AccessibilityId(id));

        if (elements.Count == 0)
        {
            elements = App.FindElements(MobileBy.Id(id));
        }

        return elements;
    }

    protected void DismissAlert()
    {
        if (App is WindowsDriver)
        {
            FindByAutomationId("SecondaryButton").Click();
        }
        else if (App is MacDriver)
        {
            // XC alert dialog.
            FindByAutomationId("action-button--999").Click();
        }
        else
        {
            // Alerts are in a different context
            // See: https://stackoverflow.com/a/36130811/109458
            // Dismissing will reset the game as the secondary action
            WaitFor(() => App.SwitchTo().Alert().Dismiss());
        }
    }


    protected void RestartApp()
    {
        CloseApp();
        LaunchApp();
    }

    protected void CloseApp()
    {
        if (App is WindowsDriver winDriver)
        {
            winDriver.CloseApp();
            return;
        }

        if (App is MacDriver)
        {
            App.ExecuteScript(MacDriverCommandTerminate, new Dictionary<string, object>() {
                {"bundleId", fixture.PackageId}
            });
            return;
        }

        App.TerminateApp(fixture.PackageId);
    }

    protected void LaunchApp()
    {
        if (App is WindowsDriver winDriver)
        {
            winDriver.LaunchApp();
            return;
        }

        if (App is MacDriver)
        {
            App.ExecuteScript(MacDriverCommandLaunch, new Dictionary<string, object>() {
                {"bundleId", fixture.PackageId}
            });
            return;
        }

        App.ActivateApp(fixture.PackageId);
    }

}
