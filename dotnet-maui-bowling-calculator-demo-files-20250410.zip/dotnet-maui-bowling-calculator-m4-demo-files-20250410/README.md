# dotnet-maui-bowling-calculator

## App Links (Android)

The app registers `bowlingcalculator://about` as a custom URL scheme. You can use this to open the About view from automated tests or the browser.

For testing the launch behavior:

```sh
adb shell am start -W -a android.intent.action.VIEW -d "bowlingcalculator://about" com.kamranayub.bowlingcalculator
```

For documentation on this, see:

- [MAUI: Android App Links](https://learn.microsoft.com/en-us/dotnet/maui/android/app-links)
- [Android Developer: Deep Linking](https://developer.android.com/training/app-links/deep-linking)