﻿using DeviceRunners.VisualRunners.Maui;

namespace DeviceTests
{
    public partial class BowlingVisualRunnerApp : VisualRunnerApp
    {
        public BowlingVisualRunnerApp()
        {
            InitializeComponent();
        }
    }
}