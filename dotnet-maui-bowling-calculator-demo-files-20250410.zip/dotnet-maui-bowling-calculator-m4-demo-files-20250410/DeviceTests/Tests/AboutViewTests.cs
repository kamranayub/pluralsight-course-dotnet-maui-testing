﻿using BowlingCalculator.Views;
using BowlingCalculator.ViewModels;
using Microsoft.Maui.Handlers;
using Microsoft.Maui.Platform;
using DeviceTests.Support;

#if WINDOWS
using BowlingCalculator.Platforms.Windows;
using Microsoft.UI.Xaml.Controls;
#endif

namespace DeviceTests.Tests
{
    [Collection("ThemeTests")]
    public class AboutViewTests : UITests<AboutView>
    {
        protected override Task SetupAsync()
        {
            CurrentPage.SetAppThemeColor(
                VisualElement.BackgroundColorProperty, 
                light: Colors.Red, dark: Colors.Blue);

            return base.SetupAsync();
        }

        protected override Task TeardownAsync()
        {
            CurrentPage.RemoveBinding(
                VisualElement.BackgroundColorProperty);

            var vm = (AboutViewModel)CurrentPage.BindingContext;
            vm.SelectedAppTheme = (int)AppTheme.Unspecified;

            return base.TeardownAsync();
        }

        [UITheory]
        [InlineData(AppTheme.Unspecified, "System Default", "#FF0000")]
        [InlineData(AppTheme.Light, "Light", "#FF0000")]
        [InlineData(AppTheme.Dark, "Dark", "#0000FF")]
        public void CanChangeAppTheme(AppTheme theme, string expectedText, string expectedColorHex)
        {
            var vm = (AboutViewModel)CurrentPage.BindingContext;
            vm.SelectedAppTheme = (int)theme;

            var appThemePicker = CurrentPage.FindByName<Picker>("appThemePicker");
            var handler = appThemePicker.ToHandler<PickerHandler>(MauiContext);
            var selectedText = GetControlText(handler.PlatformView);

            Assert.Equal(expectedColorHex, CurrentPage.BackgroundColor.ToHex());
            Assert.Equal(expectedText, selectedText);            
        }

#if ANDROID || IOS || MACCATALYST
        private string? GetControlText(MauiPicker picker)
        {
            return picker.Text;
        }
#endif

#if WINDOWS
        private string? GetControlText(ComboBox platformView)
        {
            return platformView.SelectedItem?.ToString();
        }
#endif
    }
}
