﻿#if WINDOWS
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
#endif

namespace DeviceTests.Tests;

[Collection("UITests")]
public abstract class UITests<T> : IAsyncLifetime
    where T : Microsoft.Maui.Controls.Page
{
    protected T CurrentPage { get; private set; } = null!;

    protected IMauiContext MauiContext { get; private set; } = null!;

    public async Task InitializeAsync()
    {
        Routing.RegisterRoute("uitests", typeof(T));

        await Shell.Current.GoToAsync("uitests");

        CurrentPage = (T)Shell.Current.CurrentPage;

        await WaitForLoaded(CurrentPage);
        await SetupAsync();

        MauiContext = CurrentPage.Handler!.MauiContext!;
    }

    protected virtual Task SetupAsync()
    {
        return Task.CompletedTask;
    }

    public async Task DisposeAsync()
    {

        await TeardownAsync();

        CurrentPage = null!;

        await Shell.Current.GoToAsync("..");

        Routing.UnRegisterRoute("uitests");
    }

    protected virtual Task TeardownAsync()
    {
        return Task.CompletedTask;
    }

    protected static async Task WaitForLoaded(VisualElement element, int timeout = 1000)
    {
        if (element.IsLoaded)
            return;

        var tcs = new TaskCompletionSource();

        element.Loaded += OnLoaded;

        await Task.WhenAny(tcs.Task, Task.Delay(timeout));

        element.Loaded -= OnLoaded;

        Assert.True(element.IsLoaded);

        void OnLoaded(object? sender, EventArgs e)
        {
            element.Loaded -= OnLoaded;
            tcs.SetResult();
        }
    }
}
