﻿using BowlingCalculator.Converters;
using DeviceTests.Support;

namespace DeviceTests.Tests;

[Collection("ThemeTests")]
public class ScoreGridTextColorConverterTests : IAsyncLifetime
{
    [Fact]
    public void Convert_WhenScoreIsSpare_ReturnsTertiaryResource()
    {
        var converter = new ScoreGridTextColorConverter();
        var result = converter.Convert("/", null, null, null);
        Assert.Equal(Application.Current!.Resources["Tertiary"], result);
    }

    [Fact]
    public void Convert_WhenScoreIsStrike_ReturnsTertiaryResource()
    {
        var converter = new ScoreGridTextColorConverter();
        var result = converter.Convert("X", null, null, null);
        Assert.Equal(Application.Current!.Resources["Tertiary"], result);
    }

    [Fact]
    public async Task Convert_WhenRegularScore_ReturnsSecondaryDarkTextResourceIfDarkAppTheme()
    {
        await MainThread.InvokeOnMainThreadAsync(() =>
            Application.Current!.RequestThemeChangeAsync(AppTheme.Dark));

        var converter = new ScoreGridTextColorConverter();
        var result = converter.Convert(1, null, null, null);
        Assert.Equal(Application.Current!.Resources["SecondaryDarkText"], result);
    }

    [Fact]
    public async Task Convert_WhenRegularScore_ReturnsPrimaryResourceIfLightAppTheme()
    {
        await MainThread.InvokeOnMainThreadAsync(() =>
            Application.Current!.RequestThemeChangeAsync(AppTheme.Light));

        var converter = new ScoreGridTextColorConverter();
        var result = converter.Convert(1, null, null, null);
        Assert.Equal(Application.Current!.Resources["Primary"], result);
    }

    public Task InitializeAsync()
    {
        return Task.CompletedTask;
    }

    public async Task DisposeAsync()
    {
        await MainThread.InvokeOnMainThreadAsync(() =>
            Application.Current!.RequestThemeChangeAsync(AppTheme.Unspecified));
    }
}
