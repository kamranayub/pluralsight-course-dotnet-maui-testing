﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace DeviceTests.Support
{
    public static class ApplicationThemeExtensions
    {
        public static async Task RequestThemeChangeAsync(this Application application, AppTheme theme, int timeout = 1000)
        {
            // if theme is the same continue on captured context
            if (application.UserAppTheme == theme)
            {
                return;
            }

            // if user app theme is unspecified, then requested theme could be the same
            if (application.RequestedTheme == theme)
            {
                return;
            }

            var tcs = new TaskCompletionSource();

            application.RequestedThemeChanged += OnRequestedThemeChanged;

            application.UserAppTheme = theme;

            await Task.WhenAny(tcs.Task, Task.Delay(timeout));

            application.RequestedThemeChanged -= OnRequestedThemeChanged;

            void OnRequestedThemeChanged(object? sender, AppThemeChangedEventArgs e)
            {
                application.RequestedThemeChanged -= OnRequestedThemeChanged;
                tcs.SetResult();
            }
        }
    }
}
