﻿namespace BowlingCalculator
{
    public partial class AppShell : Shell
    {
        public AppShell()
        {
            InitializeComponent();

            Routing.RegisterRoute(nameof(Views.AboutView), typeof(Views.AboutView));
            Routing.RegisterRoute(nameof(Views.GameView), typeof(Views.GameView));
            Routing.RegisterRoute(nameof(Views.AddPlayerView), typeof(Views.AddPlayerView));
            Routing.RegisterRoute(nameof(Views.ChangelogView), typeof(Views.ChangelogView));
            Routing.RegisterRoute(nameof(Views.PinPickerView), typeof(Views.PinPickerView));
        }
    }
}
