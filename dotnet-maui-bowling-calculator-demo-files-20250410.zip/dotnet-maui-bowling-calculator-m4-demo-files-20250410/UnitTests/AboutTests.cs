﻿using BowlingCalculator.Storage;
using BowlingCalculator.ViewModels;
using CommunityToolkit.Mvvm.Input;
using Moq;

namespace UnitTests
{

    public class AboutTests
    {
        private readonly AboutViewModel _sut;
        private readonly Mock<ILauncher> _mockLauncher;
        private readonly Mock<IBrowser> _mockBrowser;
        private readonly Mock<IEmail> _mockEmail;
        private readonly Mock<ThemeStore> _mockThemeStore;

        public AboutTests()
        {
            _mockLauncher = new Mock<ILauncher>(MockBehavior.Strict);
            _mockBrowser = new Mock<IBrowser>(MockBehavior.Strict);
            _mockEmail = new Mock<IEmail>(MockBehavior.Strict);
            _mockThemeStore = new Mock<ThemeStore>();
            _sut = new AboutViewModel(_mockLauncher.Object, _mockBrowser.Object, _mockEmail.Object, _mockThemeStore.Object);
        }

        [Fact]
        public async Task OpenWebsiteCommand_Launches_Browser()
        {
            var asyncCommand = _sut.OpenWebsiteCommand;

            _mockBrowser.Setup(x => x.OpenAsync(new Uri(_sut.Website), It.IsAny<BrowserLaunchOptions>()))
                .ReturnsAsync(true)
                .Verifiable(Times.Once());

            await asyncCommand.ExecuteAsync(null);

            _mockBrowser.VerifyAll();
        }

        [Fact]
        public async Task OpenPrivacyCommand_Launches_Browser()
        {
            var asyncCommand = _sut.OpenPrivacyCommand;

            _mockBrowser.Setup(x => x.OpenAsync(new Uri(_sut.PrivacyPolicy), It.IsAny<BrowserLaunchOptions>()))
                .ReturnsAsync(true)
                .Verifiable(Times.Once());

            await asyncCommand.ExecuteAsync(null);

            _mockBrowser.VerifyAll();
        }

        [Fact]
        public async Task OpenFeedbackSiteCommand_Launches_Browser()
        {
            var asyncCommand = _sut.OpenFeedbackSiteCommand;

            _mockBrowser.Setup(x => x.OpenAsync(new Uri(_sut.FeedbackSite), It.IsAny<BrowserLaunchOptions>()))
                .ReturnsAsync(true)
                .Verifiable(Times.Once());

            await asyncCommand.ExecuteAsync(null);

            _mockBrowser.VerifyAll();
        }

        [Fact]
        public async Task OpenProjectSiteCommand_Launches_Browser()
        {
            var asyncCommand = _sut.OpenProjectSiteCommand;

            _mockBrowser.Setup(x => x.OpenAsync(new Uri(_sut.ProjectSite), It.IsAny<BrowserLaunchOptions>()))
                .ReturnsAsync(true)
                .Verifiable(Times.Once());

            await asyncCommand.ExecuteAsync(null);

            _mockBrowser.VerifyAll();
        }


        [Fact]
        public async Task Rate_Command_Should_Open_Marketplace_URL_To_PackageName()
        {
            var asyncCommand = _sut.OpenRateCommand;

            _mockLauncher.Setup(x => x.CanOpenAsync(new Uri("market://")))
                .ReturnsAsync(true)
                .Verifiable(Times.Once());
            _mockLauncher.Setup(x => x.OpenAsync(new Uri("market://details?id=" + _sut.PackageName)))
                .ReturnsAsync(true)
                .Verifiable(Times.Once());

            await asyncCommand.ExecuteAsync(null);

            _mockLauncher.VerifyAll();
        }

        [Fact]
        public async Task Rate_Command_Not_Should_Open_Marketplace_URL_To_PackageName_IfNotSupported()
        {
            var asyncCommand = _sut.OpenRateCommand;

            _mockLauncher.Setup(x => x.CanOpenAsync(new Uri("market://")))
                .ReturnsAsync(false)
                .Verifiable(Times.Once());
            _mockLauncher.Setup(x => x.OpenAsync(It.IsAny<Uri>()))
                .ReturnsAsync(true)
                .Verifiable(Times.Never());

            await asyncCommand.ExecuteAsync(null);

            _mockLauncher.VerifyAll();
        }


        [Fact]
        public async Task OpenSupportEmail_Launches_Compose_Email_With_Defaults()
        {
            var asyncCommand = _sut.OpenSupportEmailCommand;

            _mockEmail.SetupGet(x => x.IsComposeSupported).Returns(true);
            _mockEmail.Setup(x => x.ComposeAsync(It.Is<EmailMessage>(m => m.Subject == "Issue with Bowling Calc app")))
                .Returns(Task.CompletedTask)
                .Verifiable(Times.Once());

            await asyncCommand.ExecuteAsync(null);

            _mockEmail.VerifyAll();
        }

    }
}
