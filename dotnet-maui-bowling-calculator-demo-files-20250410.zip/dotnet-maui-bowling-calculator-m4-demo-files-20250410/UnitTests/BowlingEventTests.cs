﻿using BowlingCalculator.BowlingGame;
using BowlingCalculator.BowlingGame.Messages;
using CommunityToolkit.Mvvm.Messaging;
using Moq;

namespace UnitTests;

public class BowlingEventTests
{
    private readonly Bowling _sut;
    private readonly Mock<IMessenger> _mockMessenger;

    public BowlingEventTests()
    {
        _mockMessenger = new Mock<IMessenger>();

        _sut = new Bowling(_mockMessenger.Object);
    }

    [Fact]
    public void Bowling_Should_Emit_GameStarted_Event_When_First_Player_Is_Added()
    {
        _mockMessenger
            .Setup(x => x.Send(It.IsAny<Game.Started>(), default(GameToken)))
            .Verifiable(Times.Once);

        var player1 = _sut.AddPlayer("Kamran");
        var player2 = _sut.AddPlayer("Cassie");

        _mockMessenger.VerifyAll();
    }

    [Fact]
    public void Bowling_Should_Emit_PlayerAdded_Event_When_Any_Player_Is_Added()
    {
        _mockMessenger
            .Setup(x => x.Send(It.IsAny<Game.PlayerAdded>(), default(GameToken)))            
            .Verifiable(Times.Exactly(2));

        var player1 = _sut.AddPlayer("Kamran");
        var player2 = _sut.AddPlayer("Cassie");

        _mockMessenger.VerifyAll();
    }

    [Fact]
    public void Bowling_Should_Emit_InProgress_Event_On_First_Throw()
    {
        _mockMessenger
            .Setup(x => x.Send(It.IsAny<Game.InProgress>(), default(GameToken)))
            .Verifiable(Times.Once);

        var player = _sut.AddPlayer("Kamran");

        _sut.Bowl(1);
        _sut.Bowl(4);

        _mockMessenger.VerifyAll();
    }

    [Fact]
    public void Bowling_Should_Emit_Turn_Event_On_All_Turns()
    {
        _mockMessenger
            .Setup(x => x.Send(It.IsAny<Game.Turn>(), default(GameToken)))
            .Verifiable(Times.Exactly(12));

        var player = _sut.AddPlayer("Kamran");

        for (var i = 0; i < 12; i++)
        {
            _sut.Bowl(10);
        }

        _mockMessenger.VerifyAll();
    }

    [Fact]
    public void Bowling_Should_Emit_Ended_Event_On_Last_Throw()
    {
        _mockMessenger
            .Setup(x => x.Send(It.IsAny<Game.Ended>(), default(GameToken)))
            .Verifiable(Times.Once);

        var player = _sut.AddPlayer("Kamran");

        for (var i = 0; i < 12; i++)
        {
            _sut.Bowl(10);
        }

        _mockMessenger.VerifyAll();
    }

    [Fact]
    public void Bowling_Should_Emit_Reset_Event_When_Requesting_A_Reset()
    {
        _mockMessenger
            .Setup(x => x.Send(It.IsAny<Game.Reset>(), default(GameToken)))
            .Verifiable(Times.Once);

        var player = _sut.AddPlayer("Kamran");

        _sut.Receive(new RequestGameResetMessage());

        _mockMessenger.VerifyAll();
    }
}