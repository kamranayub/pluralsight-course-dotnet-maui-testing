﻿using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Appium.Enums;
using OpenQA.Selenium.Appium.Mac;
using OpenQA.Selenium.Appium.Service;
using UITests;

[assembly: AssemblyFixture(typeof(AppiumFixture))]

namespace UITests;

public class AppiumFixture : IDisposable
{
    private readonly AppiumDriver? session;
    private readonly AppiumLocalService? service;

    public AppiumDriver App => session ?? throw new NullReferenceException("AppiumDriver is null");

    public string PackageId => "com.kamranayub.bowlingcalculator";

    public AppiumFixture()
    {
        try
        {
            // If you started an Appium server manually, make sure to comment out the next line
            // This line starts a local Appium server for you as part of the test run
            service = AppiumServerHelper.StartAppiumLocalServer();

            var macOSOptions = new AppiumOptions
            {
                // Specify mac2 as the driver, typically don't need to change this
                AutomationName = "mac2",
                // Always Mac for Mac
                PlatformName = "Mac",
                // The full path to the .app file to test or the bundle id if the app is already installed on the device
                App = PackageId
            };

            macOSOptions.AddAdditionalAppiumOption(IOSMobileCapabilityType.BundleId, PackageId);

            // Note there are many more options that you can use to influence the app under test according to your needs

            session = new MacDriver(macOSOptions);
        } 
        catch
        {
            Dispose();

            throw;
        }

        Assert.NotNull(session);
    }

    public void Dispose()
    {
        session?.Quit();

        // If an Appium server was started locally above, make sure we clean it up here
        AppiumServerHelper.DisposeAppiumLocalServer(service);        
    }
}